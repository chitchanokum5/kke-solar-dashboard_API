@echo off
title Solar Dashboard Local Server Launcher

echo ==========================================================
echo  Starting local server for Solar Dashboard...
echo  (This resolves CORS issues with Google Sheets in browsers)
echo ==========================================================
echo.
echo  * Please do not close this window while using the dashboard *
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0server.ps1"

pause
